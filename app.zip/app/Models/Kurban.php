<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Kurban extends Model
{
    use HasFactory;

        protected $guarded = [];
        protected $table = 'kurban';
}

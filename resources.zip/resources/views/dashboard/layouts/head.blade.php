<link rel="shortcut icon" href="{{ asset('db/assets/images/msjd.png') }}">

<link href="{{ asset('db/assets/plugins/morris/morris.css') }}" rel="stylesheet">
<link href="{{ asset('db/assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('db/assets/css/icons.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('db/assets/css/style.css') }}" rel="stylesheet" type="text/css">
<!-- SweetAlert2 -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">
<link href="assets/plugins/summernote/summernote-bs4.css" rel="stylesheet" />

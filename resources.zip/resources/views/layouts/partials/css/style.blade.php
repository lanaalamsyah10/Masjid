<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/flaticon-set.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/elegant-icons.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/magnific-popup.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/owl.carousel.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/owl.theme.default.min.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/animate.css') }}" rel="stylesheet" />
<link href="{{ asset('assets/css/bootsnav.css') }}" rel="stylesheet" />
<link href="{{ asset('style.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">

<!-- ========== End Stylesheet ========== -->

<!-- ========== Google Fonts ========== -->

<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">
